# DjangoDashboardCorona
Dashboard made in dajngo application


ALl helpfull websites

https://jsfiddle.net/gh/get/library/pure/highcharts/highcharts/tree/master/samples/maps/demo/tooltip/

https://www.highcharts.com/maps/demo

https://who.sprinklr.com/

https://apexcharts.com/javascript-chart-demos/heatmap-charts/multiple-series/
